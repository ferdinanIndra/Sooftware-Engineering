<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        // Mock data for demo
        $activeReservations = [
            [
                'id' => 'B4-045',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'expires' => 'Dec 15, 2024',
                'status' => 'active'
            ],
            [
                'id' => 'B4-023',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'expires' => 'Today, 8:00 PM',
                'status' => 'expires_soon'
            ]
        ];

        $recentActivity = [
            [
                'action' => 'Locker unlocked',
                'location' => 'Building B - Library, 4th Floor',
                'time' => '2 hours ago'
            ],
            [
                'action' => 'Rental extended',
                'location' => 'Building B - Library, 4th Floor',
                'time' => '1 day ago'
            ],
            [
                'action' => 'New reservation',
                'location' => 'Building B - Library, 4th Floor',
                'time' => '3 days ago'
            ]
        ];

        return view('dashboard', compact('activeReservations', 'recentActivity'));
    }
}
