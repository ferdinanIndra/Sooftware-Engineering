<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LockerMapController extends Controller
{
    public function index()
    {
        // Mock data for available lockers
        $availableLockers = [
            [
                'id' => 'B4-045',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'size' => 'Medium',
                'features' => ['Power Outlet', 'Climate Controlled'],
                'status' => 'available'
            ],
            [
                'id' => 'B4-112',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'size' => 'Large',
                'features' => ['Power Outlet', 'Extra Space'],
                'status' => 'available'
            ],
            [
                'id' => 'B4-067',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'size' => 'Small',
                'features' => ['Ventilated', 'Study Area Access'],
                'status' => 'available'
            ],
            [
                'id' => 'B4-234',
                'building' => 'Building B - Library',
                'floor' => '4th Floor',
                'size' => 'Extra Large',
                'features' => ['Power Outlet', 'Secure Lock', 'XXL Size'],
                'status' => 'available'
            ]
        ];

        $buildings = [
            'Building B - Library'
        ];

        return view('map', compact('availableLockers', 'buildings'));
    }
}
