<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);

        // For demo purposes, we'll accept any UPJ email
        if (str_ends_with($request->email, '@student.upj.ac.id')) {
            // Create a simple session for demo
            Session::put('user', [
                'name' => 'Sarah',
                'email' => $request->email,
                'student_id' => '2021001234'
            ]);
            
            return redirect()->route('dashboard')->with('success', 'Welcome back!');
        }

        return back()->withErrors([
            'email' => 'Please use your UPJ student email (@student.upj.ac.id)',
        ]);
    }

    public function logout()
    {
        Session::forget('user');
        return redirect()->route('home')->with('success', 'Logged out successfully!');
    }
}
