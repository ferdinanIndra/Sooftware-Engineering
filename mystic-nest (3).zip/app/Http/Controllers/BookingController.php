<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function index()
    {
        $buildings = [
            'building-b' => 'Building B - Library'
        ];

        $lockerSizes = [
            ['size' => 'Small', 'dimensions' => '6×12×18'],
            ['size' => 'Medium', 'dimensions' => '12×12×18'],
            ['size' => 'Large', 'dimensions' => '12×18×24'],
            ['size' => 'X-Large', 'dimensions' => '18×24×36']
        ];

        $durations = [
            ['duration' => '4 Hours', 'popular' => false],
            ['duration' => '1 Day', 'popular' => true],
            ['duration' => '1 Week', 'popular' => false],
            ['duration' => '1 Month', 'popular' => false],
            ['duration' => '1 Semester', 'popular' => true],
            ['duration' => 'Custom', 'popular' => false]
        ];

        return view('booking', compact('buildings', 'lockerSizes', 'durations'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'building' => 'required',
            'floor' => 'required',
            'size' => 'required',
            'start_date' => 'required|date',
            'duration' => 'required'
        ]);

        // Mock booking creation
        $bookingId = 'UPJ-' . rand(1000, 9999);

        return redirect()->route('dashboard')->with('success', "Locker booked successfully! Booking ID: $bookingId");
    }
}
