<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'LockerUPJ - Smart Locker System for UPJ Students')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-primary { background: linear-gradient(to right, #3B82F6, #1E40AF); }
        .gradient-accent { background: linear-gradient(to right, #3B82F6, #8B5CF6); }
        .gradient-surface { background: linear-gradient(to bottom right, #ffffff, #f1f5f9); }
        .text-gradient { background: linear-gradient(to right, #3B82F6, #1E40AF); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .animate-pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: .5; } }
    </style>
</head>
<body class="bg-white text-gray-900">
    
    @if(!request()->is('login'))
    <!-- Navigation -->
    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <!-- Logo -->
                <div class="flex items-center space-x-2">
                    <div class="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                        <div class="w-4 h-4 bg-white rounded-sm"></div>
                    </div>
                    <span class="font-bold text-xl text-gray-900">LockerUPJ</span>
                </div>

                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="{{ route('home') }}" class="text-gray-900 hover:text-blue-600 transition-colors {{ request()->is('/') ? 'font-semibold' : '' }}">
                        Home
                    </a>
                    @auth
                    <a href="{{ route('dashboard') }}" class="text-gray-600 hover:text-blue-600 transition-colors {{ request()->is('dashboard') ? 'font-semibold text-gray-900' : '' }}">
                        Dashboard
                    </a>
                    <a href="{{ route('map') }}" class="text-gray-600 hover:text-blue-600 transition-colors {{ request()->is('map') ? 'font-semibold text-gray-900' : '' }}">
                        Locker Map
                    </a>
                    <a href="{{ route('booking') }}" class="text-gray-600 hover:text-blue-600 transition-colors {{ request()->is('booking') ? 'font-semibold text-gray-900' : '' }}">
                        Book Now
                    </a>
                    <form method="POST" action="{{ route('logout') }}" class="inline">
                        @csrf
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors">
                            Logout
                        </button>
                    </form>
                    @else
                    <a href="{{ route('login') }}" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-all hover:scale-105">
                        Student Login
                    </a>
                    @endauth
                </div>

                <!-- Mobile menu button -->
                <button class="md:hidden" id="mobile-menu-btn">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>

            <!-- Mobile Navigation -->
            <div class="md:hidden hidden py-4 space-y-4" id="mobile-menu">
                <a href="{{ route('home') }}" class="block text-gray-900 hover:text-blue-600 transition-colors">Home</a>
                @auth
                <a href="{{ route('dashboard') }}" class="block text-gray-600 hover:text-blue-600 transition-colors">Dashboard</a>
                <a href="{{ route('map') }}" class="block text-gray-600 hover:text-blue-600 transition-colors">Locker Map</a>
                <a href="{{ route('booking') }}" class="block text-gray-600 hover:text-blue-600 transition-colors">Book Now</a>
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="w-full text-left bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors">
                        Logout
                    </button>
                </form>
                @else
                <a href="{{ route('login') }}" class="block w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors text-center">
                    Student Login
                </a>
                @endauth
            </div>
        </div>
    </nav>
    @endif

    <!-- Main Content -->
    <main>
        @yield('content')
    </main>

    <!-- Mobile menu toggle script -->
    <script>
        document.getElementById('mobile-menu-btn')?.addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        });
    </script>

    @stack('scripts')
</body>
</html>
