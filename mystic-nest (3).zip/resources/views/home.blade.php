@extends('layouts.app')

@section('title', 'LockerUPJ - Free Smart Locker System for UPJ Students')

@section('content')
<div class="min-h-screen gradient-surface">

    <!-- Hero Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8">
        <div class="container mx-auto text-center max-w-4xl">
            <div class="inline-flex items-center bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                🎓 Built for Pembangunan Jaya University
            </div>

            <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Smart Lockers for
                <span class="text-gradient"> Modern Students</span>
            </h1>
            <p class="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Reserve, access, and manage your UPJ campus lockers seamlessly. Secure
                storage solutions designed specifically for Pembangunan Jaya University students.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="{{ route('booking') }}" class="bg-blue-500 hover:bg-blue-600 text-white text-lg px-8 py-3 rounded-lg hover:scale-105 hover:shadow-xl transition-all duration-300 group">
                    Book a Locker Now
                    <span class="ml-2 group-hover:translate-x-1 transition-transform inline-block">→</span>
                </a>
                <a href="{{ route('map') }}" class="border border-gray-300 hover:border-blue-500 text-gray-700 hover:text-blue-600 text-lg px-8 py-3 rounded-lg hover:scale-105 hover:shadow-lg transition-all duration-300">
                    View Campus Map
                </a>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="text-4xl font-bold text-gradient mb-2">500+</div>
                    <p class="text-gray-600">Smart Lockers</p>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold text-gradient mb-2">24/7</div>
                    <p class="text-gray-600">Access Available</p>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold text-gradient mb-2">5,000+</div>
                    <p class="text-gray-600">Active Students</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Why Use LockerUPJ?</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                    Easy and safe locker system made just for UPJ students. Store your stuff safely anywhere on campus.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Super Safe & Secure</h3>
                    <p class="text-gray-600">Your things are protected with the best security technology. No one else can access your locker.</p>
                </div>

                <!-- Feature 2 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Student Card Access</h3>
                    <p class="text-gray-600">Book using your phone, then scan your UPJ student card barcode to unlock your locker securely!</p>
                </div>

                <!-- Feature 3 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Any Time You Need</h3>
                    <p class="text-gray-600">Rent for 1 hour, 1 day, or the whole semester. Need more time? Just extend it easily.</p>
                </div>

                <!-- Feature 4 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Building B Library Access</h3>
                    <p class="text-gray-600">Convenient locker access on the 4th floor of Building B Library for your study needs!</p>
                </div>

                <!-- Feature 5 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Share with Friends</h3>
                    <p class="text-gray-600">Let your friends use the same locker for group projects or when studying together.</p>
                </div>

                <!-- Feature 6 -->
                <div class="bg-white border-0 shadow-lg hover:shadow-xl transition-all duration-300 group rounded-lg p-6">
                    <div class="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                        <svg class="h-6 w-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">See What's Available</h3>
                    <p class="text-gray-600">Check which lockers are free right now and book them immediately.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div class="container mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                    Using LockerUPJ is super easy! Just 3 simple steps and you're done.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="text-center">
                    <div class="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                        <span class="text-2xl font-bold text-white">1</span>
                    </div>
                    <h3 class="text-xl font-semibold mb-4">Pick a Locker</h3>
                    <p class="text-gray-600">Look at the map and choose a locker that's close to you. Pick the size you need.</p>
                </div>

                <div class="text-center">
                    <div class="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                        <span class="text-2xl font-bold text-white">2</span>
                    </div>
                    <h3 class="text-xl font-semibold mb-4">Book It</h3>
                    <p class="text-gray-600">Choose how long you need it. Quick and easy booking process!</p>
                </div>

                <div class="text-center">
                    <div class="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                        <span class="text-2xl font-bold text-white">3</span>
                    </div>
                    <h3 class="text-xl font-semibold mb-4">Scan Student Card to Open</h3>
                    <p class="text-gray-600">Go to your locker and scan your UPJ student card barcode. The locker opens and you can store your stuff safely!</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 px-4 sm:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="gradient-primary text-white rounded-2xl p-12 text-center">
                <h2 class="text-3xl sm:text-4xl font-bold mb-4">Ready to Simplify Your Campus Life?</h2>
                <p class="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
                    Join thousands of UPJ students who use LockerUPJ for secure, convenient campus storage at Pembangunan Jaya University.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="{{ route('booking') }}" class="bg-white text-blue-600 hover:bg-gray-100 text-lg px-8 py-3 rounded-lg transition-colors">
                        Start Using Now →
                    </a>
                    <a href="{{ route('login') }}" class="border border-white text-white hover:bg-white hover:text-blue-600 text-lg px-8 py-3 rounded-lg transition-colors">
                        Contact Support
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-12 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white">
        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                            <div class="w-4 h-4 bg-white rounded-sm"></div>
                        </div>
                        <span class="font-bold text-xl">LockerUPJ</span>
                    </div>
                    <p class="text-gray-400">Secure, smart storage solutions exclusively for Pembangunan Jaya University students.</p>
                </div>

                <div>
                    <h3 class="font-semibold mb-4">Product</h3>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">Features</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Pricing</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Security</a></li>
                    </ul>
                </div>

                <div>
                    <h3 class="font-semibold mb-4">Support</h3>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">Help Center</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Contact Us</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">System Status</a></li>
                    </ul>
                </div>

                <div>
                    <h3 class="font-semibold mb-4">University</h3>
                    <ul class="space-y-2 text-gray-400">
                        <li><a href="#" class="hover:text-white transition-colors">About Us</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Careers</a></li>
                        <li><a href="#" class="hover:text-white transition-colors">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; 2024 LockerUPJ - Pembangunan Jaya University. All rights reserved.</p>
            </div>
        </div>
    </footer>
</div>
@endsection
