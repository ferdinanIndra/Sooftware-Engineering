<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login - LockerUPJ</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .gradient-primary { background: linear-gradient(to right, #3B82F6, #1E40AF); }
        .text-gradient { background: linear-gradient(to right, #3B82F6, #1E40AF); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative overflow-hidden">
    <!-- Animated Background Elements -->
    <div class="absolute inset-0 overflow-hidden pointer-events-none">
        <div class="absolute -top-40 -right-40 w-80 h-80 gradient-primary rounded-full opacity-10 animate-pulse"></div>
        <div class="absolute -bottom-32 -left-32 w-64 h-64 bg-purple-500/20 rounded-full opacity-10"></div>
        <div class="absolute top-1/2 left-1/4 w-32 h-32 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full opacity-5"></div>
    </div>

    <!-- Header -->
    <header class="relative z-10 p-6">
        <div class="container mx-auto">
            <div class="flex items-center justify-between">
                <a href="{{ route('home') }}" class="flex items-center space-x-2 group transition-transform hover:scale-105">
                    <div class="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center group-hover:shadow-lg transition-shadow">
                        <div class="w-4 h-4 bg-white rounded-sm"></div>
                    </div>
                    <span class="font-bold text-xl text-gray-900">LockerUPJ</span>
                </a>
                <div class="inline-flex items-center bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                    <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z"></path>
                    </svg>
                    UPJ Student Portal
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="relative z-10 container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
            <!-- Left Side - Welcome Content -->
            <div class="space-y-8">
                <div>
                    <h1 class="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 leading-tight">
                        Welcome back,
                        <span class="text-gradient block">UPJ Student!</span>
                    </h1>
                    <p class="text-xl text-gray-600 leading-relaxed">
                        Access your digital locker dashboard and manage your Pembangunan Jaya University
                        campus storage seamlessly.
                    </p>
                </div>

                <!-- Feature Highlights -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div class="text-center group cursor-pointer">
                        <div class="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                            </svg>
                        </div>
                        <h3 class="font-medium text-sm">Instant Access</h3>
                        <p class="text-xs text-gray-600">Unlock lockers instantly</p>
                    </div>

                    <div class="text-center group cursor-pointer">
                        <div class="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform delay-75">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                            </svg>
                        </div>
                        <h3 class="font-medium text-sm">Secure Storage</h3>
                        <p class="text-xs text-gray-600">Military-grade security</p>
                    </div>

                    <div class="text-center group cursor-pointer">
                        <div class="w-12 h-12 gradient-primary rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform delay-150">
                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                        <h3 class="font-medium text-sm">Share Access</h3>
                        <p class="text-xs text-gray-600">Collaborate with friends</p>
                    </div>
                </div>

                <!-- Stats -->
                <div class="bg-white/50 backdrop-blur-sm rounded-2xl p-6 border">
                    <div class="grid grid-cols-3 gap-4 text-center">
                        <div>
                            <div class="text-2xl font-bold text-gradient">500+</div>
                            <div class="text-sm text-gray-600">Smart Lockers</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold text-gradient">5K+</div>
                            <div class="text-sm text-gray-600">Active Students</div>
                        </div>
                        <div>
                            <div class="text-2xl font-bold text-gradient">24/7</div>
                            <div class="text-sm text-gray-600">Availability</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side - Login Form -->
            <div>
                <div class="bg-white/80 backdrop-blur-sm border-0 shadow-2xl rounded-xl p-8">
                    <div class="text-center pb-8">
                        <h2 class="text-2xl font-bold mb-2">Student Login</h2>
                        <p class="text-gray-600">Sign in to access your locker dashboard</p>
                    </div>

                    @if ($errors->any())
                        <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-6">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('login') }}" class="space-y-6">
                        @csrf
                        
                        <!-- Email Field -->
                        <div class="space-y-2">
                            <label for="email" class="text-sm font-medium text-gray-700">University Email</label>
                            <div class="relative group">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 group-focus-within:text-blue-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                                <input
                                    id="email"
                                    name="email"
                                    type="email"
                                    placeholder="your.email@student.upj.ac.id"
                                    value="{{ old('email') }}"
                                    class="pl-10 w-full h-12 border-2 border-gray-200 focus:border-blue-500 rounded-lg transition-all duration-200 hover:border-blue-300 outline-none"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Password Field -->
                        <div class="space-y-2">
                            <label for="password" class="text-sm font-medium text-gray-700">Password</label>
                            <div class="relative group">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 group-focus-within:text-blue-600 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                </svg>
                                <input
                                    id="password"
                                    name="password"
                                    type="password"
                                    placeholder="Enter your password"
                                    class="pl-10 w-full h-12 border-2 border-gray-200 focus:border-blue-500 rounded-lg transition-all duration-200 hover:border-blue-300 outline-none"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Remember & Forgot -->
                        <div class="flex items-center justify-between">
                            <label class="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                <span class="text-sm text-gray-600">Remember me</span>
                            </label>
                            <button type="button" class="text-sm text-blue-600 hover:text-blue-700 transition-colors">
                                Forgot password?
                            </button>
                        </div>

                        <!-- Login Button -->
                        <button
                            type="submit"
                            class="w-full h-12 text-lg font-medium gradient-primary text-white rounded-lg hover:shadow-lg hover:scale-[1.02] transition-all duration-200"
                        >
                            Sign In
                        </button>

                        <!-- Divider -->
                        <div class="relative">
                            <div class="absolute inset-0 flex items-center">
                                <div class="w-full border-t border-gray-300"></div>
                            </div>
                            <div class="relative flex justify-center text-sm">
                                <span class="px-2 bg-white text-gray-500">Or continue with</span>
                            </div>
                        </div>

                        <!-- University SSO -->
                        <button
                            type="button"
                            class="w-full h-12 border border-gray-300 hover:bg-gray-50 rounded-lg transition-colors flex items-center justify-center"
                        >
                            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z"></path>
                            </svg>
                            UPJ Single Sign-On
                        </button>

                        <!-- Sign Up Link -->
                        <div class="text-center">
                            <p class="text-sm text-gray-600">
                                Don't have an account? 
                                <button type="button" class="text-blue-600 hover:text-blue-700 font-medium transition-colors">
                                    Register here
                                </button>
                            </p>
                        </div>
                    </form>
                </div>

                <!-- Security Notice -->
                <div class="mt-6 text-center">
                    <div class="inline-flex items-center space-x-2 text-sm text-gray-600 bg-white/50 backdrop-blur-sm rounded-full px-4 py-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.031 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                        </svg>
                        <span>Secured with 256-bit SSL encryption</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
