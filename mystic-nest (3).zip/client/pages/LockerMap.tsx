import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ArrowLeft,
  Search,
  MapPin,
  Filter,
  Zap,
  Clock,
  Users,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function LockerMap() {
  return (
    <div className="min-h-screen bg-gradient-surface">
      {/* Header */}
      <header className="bg-white border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link to="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Campus Locker Map
                </h1>
                <p className="text-muted-foreground">
                  Find and reserve lockers across campus
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
              <Button>Reserve Selected</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Search & Filters */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Search Lockers</CardTitle>
                <CardDescription>
                  Find the perfect locker for your needs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by building or location..."
                    className="pl-10"
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">Building</h4>
                  <div className="space-y-2">
                    {["Building B - Library"].map((building) => (
                      <label key={building} className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        <span className="text-sm">{building}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Locker Size</h4>
                  <div className="space-y-2">
                    {["Small", "Medium", "Large", "Extra Large"].map((size) => (
                      <label key={size} className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        <span className="text-sm">{size}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Availability</h4>
                  <div className="space-y-2">
                    {[
                      "Available Now",
                      "Available Today",
                      "Available This Week",
                    ].map((availability) => (
                      <label key={availability} className="flex items-center">
                        <input type="checkbox" className="mr-2" />
                        <span className="text-sm">{availability}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Legend</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-500 rounded"></div>
                  <span className="text-sm">Available</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                  <span className="text-sm">Reserved</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-500 rounded"></div>
                  <span className="text-sm">Occupied</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-gray-400 rounded"></div>
                  <span className="text-sm">Maintenance</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Map & Results */}
          <div className="lg:col-span-3 space-y-6">
            {/* Interactive Map Placeholder */}
            <Card>
              <CardHeader>
                <CardTitle>Campus Map</CardTitle>
                <CardDescription>
                  Interactive map showing all locker locations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96 bg-muted rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Interactive campus map will be displayed here
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Click on buildings to view available lockers
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Available Lockers */}
            <Card>
              <CardHeader>
                <CardTitle>Available Lockers</CardTitle>
                <CardDescription>
                  Choose from {Math.floor(Math.random() * 50 + 20)} available
                  lockers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    {
                      id: "B4-045",
                      building: "Building B - Library",
                      floor: "4th Floor",
                      size: "Medium",
                      features: ["Power Outlet", "Climate Controlled"],
                      status: "available",
                    },
                    {
                      id: "B4-112",
                      building: "Building B - Library",
                      floor: "4th Floor",
                      size: "Large",
                      features: ["Power Outlet", "Extra Space"],
                      status: "available",
                    },
                    {
                      id: "B4-067",
                      building: "Building B - Library",
                      floor: "4th Floor",
                      size: "Small",
                      features: ["Ventilated", "Study Area Access"],
                      status: "available",
                    },
                    {
                      id: "B4-234",
                      building: "Building B - Library",
                      floor: "4th Floor",
                      size: "Extra Large",
                      features: ["Power Outlet", "Secure Lock", "XXL Size"],
                      status: "available",
                    },
                  ].map((locker) => (
                    <div
                      key={locker.id}
                      className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold">Locker #{locker.id}</h3>
                          <p className="text-sm text-muted-foreground">
                            {locker.building} • {locker.floor}
                          </p>
                        </div>
                        <Badge variant="secondary">{locker.size}</Badge>
                      </div>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {locker.features.map((feature) => (
                          <Badge
                            key={feature}
                            variant="outline"
                            className="text-xs"
                          >
                            {feature}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <div className="flex items-center">
                            <Zap className="h-4 w-4 mr-1 text-success" />
                            <span className="text-success font-medium">
                              FREE
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            Available Now
                          </div>
                        </div>
                        <Button
                          size="sm"
                          className="bg-success hover:bg-success/90"
                        >
                          Reserve FREE
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 text-center">
                  <Button variant="outline">Load More Lockers</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
