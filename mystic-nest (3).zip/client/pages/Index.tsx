import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  Shield,
  Clock,
  MapPin,
  Smartphone,
  Users,
  Zap,
  Check,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export default function Index() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-surface">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
              <span className="font-bold text-xl text-foreground">
                LockerUPJ
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className="text-foreground hover:text-primary-600 transition-colors"
              >
                Home
              </Link>
              <Link
                to="/dashboard"
                className="text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Dashboard
              </Link>
              <Link
                to="/map"
                className="text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Locker Map
              </Link>
              <Link
                to="/booking"
                className="text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Book Now
              </Link>
              {isAuthenticated ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-600">
                    Welcome, {user?.name}
                  </span>
                  <Button
                    onClick={logout}
                    variant="outline"
                    className="hover:scale-105 transition-transform"
                  >
                    Logout
                  </Button>
                </div>
              ) : (
                <Link to="/login">
                  <Button className="hover:scale-105 transition-transform">
                    Student Login
                  </Button>
                </Link>
              )}
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 space-y-4">
              <Link
                to="/"
                className="block text-foreground hover:text-primary-600 transition-colors"
              >
                Home
              </Link>
              <Link
                to="/dashboard"
                className="block text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Dashboard
              </Link>
              <Link
                to="/map"
                className="block text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Locker Map
              </Link>
              <Link
                to="/booking"
                className="block text-muted-foreground hover:text-primary-600 transition-colors"
              >
                Book Now
              </Link>
              {isAuthenticated ? (
                <div className="space-y-3">
                  <div className="text-center text-sm text-gray-600">
                    Welcome, {user?.name}
                  </div>
                  <Button
                    onClick={logout}
                    variant="outline"
                    className="w-full hover:scale-105 transition-transform"
                  >
                    Logout
                  </Button>
                </div>
              ) : (
                <Link to="/login">
                  <Button className="w-full hover:scale-105 transition-transform">
                    Student Login
                  </Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge variant="secondary" className="mb-6">
            🎓 Built for Pembangunan Jaya University
          </Badge>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
            Smart Lockers for
            <span className="gradient-primary bg-clip-text text-transparent">
              {" "}
              Modern Students
            </span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Reserve, access, and manage your UPJ campus lockers seamlessly.
            Secure storage solutions designed specifically for Pembangunan Jaya
            University students.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/booking">
              <Button
                size="lg"
                className="text-lg px-8 py-6 hover:scale-105 hover:shadow-xl transition-all duration-300 group"
              >
                Book a Locker Now
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link to="/map">
              <Button
                variant="outline"
                size="lg"
                className="text-lg px-8 py-6 hover:scale-105 hover:shadow-lg transition-all duration-300"
              >
                View Campus Map
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold gradient-primary bg-clip-text text-transparent mb-2">
                500+
              </div>
              <p className="text-muted-foreground">Smart Lockers</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-primary bg-clip-text text-transparent mb-2">
                24/7
              </div>
              <p className="text-muted-foreground">Access Available</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold gradient-primary bg-clip-text text-transparent mb-2">
                5,000+
              </div>
              <p className="text-muted-foreground">Active Students</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Why Use LockerUPJ?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Easy and safe locker system made just for UPJ students. Store your
              stuff safely anywhere on campus.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Super Safe & Secure</CardTitle>
                <CardDescription>
                  Your things are protected with the best security technology.
                  No one else can access your locker.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Smartphone className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Student Card Access</CardTitle>
                <CardDescription>
                  Book online using your laptop, then scan your UPJ student card
                  barcode with laptop camera to unlock your locker securely!
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Any Time You Need</CardTitle>
                <CardDescription>
                  Rent for 1 hour, 1 day, or the whole semester. Need more time?
                  Just extend it easily.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <MapPin className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Building B Library Access</CardTitle>
                <CardDescription>
                  Convenient locker access on the 4th floor of Building B
                  Library for your study needs!
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Share with Friends</CardTitle>
                <CardDescription>
                  Let your friends use the same locker for group projects or
                  when studying together.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
              <CardHeader>
                <div className="w-12 h-12 gradient-primary rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <CardTitle>See What's Available</CardTitle>
                <CardDescription>
                  Check which lockers are free right now and book them
                  immediately.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              How It Works
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Using LockerUPJ is super easy! Just 3 simple steps and you're
              done.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Pick a Locker</h3>
              <p className="text-muted-foreground">
                Look at the map and choose a locker that's close to you. Pick
                the size you need.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Book It</h3>
              <p className="text-muted-foreground">
                Choose how long you need it. Quick and easy booking process!
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">
                Scan Student Card to Open
              </h3>
              <p className="text-muted-foreground">
                Go to your locker and use your laptop camera to scan your UPJ
                student card barcode. The locker opens and you can store your
                stuff safely!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto">
          <Card className="gradient-primary text-white border-0">
            <CardContent className="p-12 text-center">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Ready to Simplify Your Campus Life?
              </h2>
              <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
                Join thousands of UPJ students who use LockerUPJ for secure,
                convenient campus storage at Pembangunan Jaya University.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/booking">
                  <Button
                    size="lg"
                    variant="secondary"
                    className="text-lg px-8 py-6"
                  >
                    Start Using Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-6 border-white text-white hover:bg-white hover:text-primary-600"
                >
                  Contact Support
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 bg-white rounded-sm"></div>
                </div>
                <span className="font-bold text-xl">LockerUPJ</span>
              </div>
              <p className="text-gray-400">
                Secure, smart storage solutions exclusively for Pembangunan Jaya
                University students.
              </p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link
                    to="/features"
                    className="hover:text-white transition-colors"
                  >
                    Features
                  </Link>
                </li>
                <li>
                  <Link
                    to="/pricing"
                    className="hover:text-white transition-colors"
                  >
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link
                    to="/security"
                    className="hover:text-white transition-colors"
                  >
                    Security
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link
                    to="/help"
                    className="hover:text-white transition-colors"
                  >
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link
                    to="/contact"
                    className="hover:text-white transition-colors"
                  >
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/status"
                    className="hover:text-white transition-colors"
                  >
                    System Status
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">University</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link
                    to="/about"
                    className="hover:text-white transition-colors"
                  >
                    About Us
                  </Link>
                </li>
                <li>
                  <Link
                    to="/careers"
                    className="hover:text-white transition-colors"
                  >
                    Careers
                  </Link>
                </li>
                <li>
                  <Link
                    to="/privacy"
                    className="hover:text-white transition-colors"
                  >
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; 2024 LockerUPJ - Pembangunan Jaya University. All rights
              reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
