import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import {
  Clock,
  MapPin,
  Settings,
  History,
  Package,
  Calendar,
  ArrowLeft,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function Dashboard() {
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [selectedLocker, setSelectedLocker] = useState<string | null>(null);

  const handleUnlockSuccess = (studentId: string) => {
    setIsScannerOpen(false);
    alert(
      `Locker ${selectedLocker} unlocked successfully! Student ID verified: ${studentId}`,
    );
    setSelectedLocker(null);
  };

  const handleUnlockClick = (lockerId: string) => {
    setSelectedLocker(lockerId);
    setIsScannerOpen(true);
  };

  return (
    <div className="min-h-screen bg-gradient-surface">
      {/* Header */}
      <header className="bg-white border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link to="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  Student Dashboard
                </h1>
                <p className="text-muted-foreground">
                  Welcome back, Sarah! Manage your lockers here.
                </p>
              </div>
            </div>
            <Button>
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Current Reservations */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Current Reservations
                </CardTitle>
                <CardDescription>
                  Your active locker reservations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border rounded-lg p-4 hover:shadow-lg hover:border-primary-300 transition-all duration-300 group">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="animate-pulse">
                        Active
                      </Badge>
                      <span className="font-medium group-hover:text-primary-600 transition-colors">
                        Building B - Library, 4th Floor
                      </span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      Locker #B4-045
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground space-x-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      Expires: Dec 15, 2024
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      Building B - Library, 4th Floor
                    </div>
                  </div>
                  <div className="mt-3 flex space-x-2">
                    <Button
                      size="sm"
                      className="hover:scale-105 transition-transform group-hover:shadow-md"
                      onClick={() => handleUnlockClick("B4-045")}
                    >
                      <svg
                        className="h-4 w-4 mr-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                        ></path>
                      </svg>
                      Scan to Unlock
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="hover:scale-105 transition-transform"
                    >
                      Extend Rental
                    </Button>
                  </div>
                </div>

                <div className="border rounded-lg p-4 hover:shadow-lg hover:border-warning-300 transition-all duration-300 group bg-gradient-to-r from-warning-50/50 to-transparent">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-warning text-warning-foreground animate-pulse">
                        Expires Soon
                      </Badge>
                      <span className="font-medium group-hover:text-warning-600 transition-colors">
                        Building B - Library, 4th Floor
                      </span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      Locker #B4-023
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground space-x-4">
                    <div className="flex items-center text-warning-600">
                      <Clock className="h-4 w-4 mr-1" />
                      Expires: Today, 8:00 PM
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      Building B - Library, 4th Floor
                    </div>
                  </div>
                  <div className="mt-3 flex space-x-2">
                    <Button
                      size="sm"
                      className="hover:scale-105 transition-transform group-hover:shadow-md"
                      onClick={() => handleUnlockClick("B4-023")}
                    >
                      <svg
                        className="h-4 w-4 mr-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                        ></path>
                      </svg>
                      Scan to Unlock
                    </Button>
                    <Button
                      size="sm"
                      className="bg-warning hover:bg-warning/90 text-warning-foreground hover:scale-105 transition-all"
                    >
                      Extend Now
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <History className="h-5 w-5 mr-2" />
                  Recent Activity
                </CardTitle>
                <CardDescription>Your locker usage history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    {
                      action: "Locker unlocked",
                      location: "Building B - Library, 4th Floor",
                      time: "2 hours ago",
                    },
                    {
                      action: "Rental extended",
                      location: "Building B - Library, 4th Floor",
                      time: "1 day ago",
                    },
                    {
                      action: "New reservation",
                      location: "Building B - Library, 4th Floor",
                      time: "3 days ago",
                    },
                  ].map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between py-2 border-b last:border-b-0"
                    >
                      <div>
                        <p className="font-medium">{activity.action}</p>
                        <p className="text-sm text-muted-foreground">
                          {activity.location}
                        </p>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {activity.time}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common tasks</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/booking">
                  <Button className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Book New Locker
                  </Button>
                </Link>
                <Link to="/map">
                  <Button variant="outline" className="w-full justify-start">
                    <MapPin className="h-4 w-4 mr-2" />
                    View Campus Map
                  </Button>
                </Link>
                <Button variant="outline" className="w-full justify-start">
                  <History className="h-4 w-4 mr-2" />
                  View Full History
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Summary</CardTitle>
                <CardDescription>Your usage overview</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    Active Reservations
                  </span>
                  <span className="font-medium">2</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    Total Bookings
                  </span>
                  <span className="font-medium">24</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    This Month
                  </span>
                  <span className="font-medium">$45.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">
                    Member Since
                  </span>
                  <span className="font-medium">Sep 2024</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      <BarcodeScanner
        isOpen={isScannerOpen}
        onClose={() => {
          setIsScannerOpen(false);
          setSelectedLocker(null);
        }}
        onSuccess={handleUnlockSuccess}
        title={`Unlock Locker ${selectedLocker}`}
        description="Scan your UPJ student card barcode to unlock your locker"
      />
    </div>
  );
}
