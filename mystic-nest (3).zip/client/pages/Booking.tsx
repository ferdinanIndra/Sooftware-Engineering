import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  CreditCard,
  Shield,
  Check,
} from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function Booking() {
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedStudentId, setScannedStudentId] = useState("");
  const [isCardRegistered, setIsCardRegistered] = useState(false);

  const handleScanSuccess = (studentId: string) => {
    setScannedStudentId(studentId);
    setIsCardRegistered(true);
    setIsScannerOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-surface">
      {/* Header */}
      <header className="bg-white border-b border-border p-6">
        <div className="container mx-auto">
          <div className="flex items-center space-x-4">
            <Link to="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Book a Locker - <span className="text-success">FREE</span>
              </h1>
              <p className="text-muted-foreground">
                Reserve your secure storage space completely free - no charges,
                no fees!
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Booking Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Step 1: Location & Size */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Step 1: Choose Location & Size
                </CardTitle>
                <CardDescription>
                  Select your preferred building and locker size
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="building">Building</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select building" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="building-b">
                          Building B - Library
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="floor">Floor</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select floor" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="4th">4th Floor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label>Locker Size</Label>
                  <div className="mt-2">
                    <div className="border rounded-lg p-4 bg-primary-50 border-primary-200">
                      <h4 className="font-medium text-lg">Medium</h4>
                      <p className="text-sm text-muted-foreground">12×12×18"</p>
                      <p className="text-sm font-medium text-success">FREE</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Perfect size for books, laptop, and personal items
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Step 2: Duration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Step 2: Select Duration
                </CardTitle>
                <CardDescription>
                  Choose how long you need the locker
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="start-date">Start Date</Label>
                    <Input type="date" id="start-date" />
                  </div>

                  <div>
                    <Label htmlFor="start-time">Start Time</Label>
                    <Input type="time" id="start-time" />
                  </div>
                </div>

                <div>
                  <Label>Rental Duration</Label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                    {[
                      { duration: "4 Hours", popular: false },
                      { duration: "1 Day", popular: true },
                      { duration: "1 Week", popular: false },
                      { duration: "1 Month", popular: false },
                      { duration: "1 Semester", popular: true },
                      { duration: "Custom", popular: false },
                    ].map((option) => (
                      <div
                        key={option.duration}
                        className="border rounded-lg p-3 cursor-pointer hover:border-primary-500 transition-colors relative hover:shadow-md"
                      >
                        {option.popular && (
                          <Badge className="absolute -top-2 left-2 text-xs">
                            Popular
                          </Badge>
                        )}
                        <h4 className="font-medium">{option.duration}</h4>
                        <p className="text-sm font-medium text-success">FREE</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Step 3: Additional Options */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  Step 3: Additional Options
                </CardTitle>
                <CardDescription>
                  Enhance your locker experience
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    {
                      name: "Insurance Protection",
                      description: "Cover items up to $500",
                      price: "FREE",
                    },
                    {
                      name: "SMS Notifications",
                      description: "Get unlock codes via text",
                      price: "FREE",
                    },
                    {
                      name: "Share Access",
                      description: "Allow friends to access",
                      price: "FREE",
                    },
                    {
                      name: "Auto-Extend",
                      description: "Automatic renewal if needed",
                      price: "FREE",
                    },
                  ].map((option) => (
                    <label
                      key={option.name}
                      className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-muted/50"
                    >
                      <input type="checkbox" />
                      <div className="flex-1">
                        <h4 className="font-medium">{option.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {option.description}
                        </p>
                      </div>
                      <span className="text-sm font-medium text-success">
                        {option.price}
                      </span>
                    </label>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Step 4: Student Card Registration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <svg
                    className="h-5 w-5 mr-2"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                    ></path>
                  </svg>
                  Step 4: Register Student Card
                </CardTitle>
                <CardDescription>
                  Scan your UPJ student card barcode to register for locker
                  access
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg
                      className="h-10 w-10 text-blue-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M12 12h-4.01M12 12v4m6-4h.01M12 8h.01M12 8h-4.01M12 8V4m6 4h.01m-.01 0h2m-2 0h-.01m.01 0V4m0 0h2M6 12h.01M6 12H4m2 0v.01M6 12V8m0 4v4m0-4h-.01M6 8h.01M6 8H4m2 0V4m0 4h-.01"
                      ></path>
                    </svg>
                  </div>
                  {!isCardRegistered ? (
                    <>
                      <h3 className="text-lg font-semibold mb-2">
                        Scan Student Card Barcode
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Click the button below to activate your laptop camera
                        and scan your UPJ student card barcode
                      </p>

                      <Button
                        className="w-full mb-4"
                        size="lg"
                        onClick={() => setIsScannerOpen(true)}
                      >
                        <svg
                          className="h-5 w-5 mr-2"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
                          ></path>
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"
                          ></path>
                        </svg>
                        Activate Laptop Camera
                      </Button>

                      <div className="text-xs text-gray-500 text-center mb-4">
                        Or manually enter your student ID below
                      </div>

                      <div>
                        <Label
                          htmlFor="student-id"
                          className="text-sm font-medium"
                        >
                          Student ID
                        </Label>
                        <div className="flex space-x-2 mt-1">
                          <Input
                            id="student-id"
                            placeholder="Enter your UPJ Student ID"
                            value={scannedStudentId}
                            onChange={(e) =>
                              setScannedStudentId(e.target.value)
                            }
                          />
                          <Button
                            onClick={() => {
                              if (scannedStudentId.trim()) {
                                setIsCardRegistered(true);
                              }
                            }}
                            disabled={!scannedStudentId.trim()}
                          >
                            Register
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Check className="h-10 w-10 text-green-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-green-600 mb-2">
                        Card Registered Successfully!
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Student ID:{" "}
                        <span className="font-mono bg-gray-100 px-2 py-1 rounded">
                          {scannedStudentId}
                        </span>
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setIsCardRegistered(false);
                          setScannedStudentId("");
                        }}
                      >
                        Scan Different Card
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Step 5: Confirmation */}
            <Card className="bg-gradient-to-r from-success-50 to-primary-50 border-success">
              <CardHeader>
                <CardTitle className="flex items-center text-success">
                  <Check className="h-5 w-5 mr-2" />
                  Step 5: Confirmation
                </CardTitle>
                <CardDescription>
                  Student card registered successfully!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-8">
                  <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-success mb-2">
                    Reservation Complete!
                  </h3>
                  <p className="text-muted-foreground">
                    Your student card is registered. Use barcode scanning to
                    unlock your locker.
                  </p>
                </div>

                <div className="p-4 bg-success/10 rounded-lg border border-success/20">
                  <div className="flex items-center text-sm text-success">
                    <Shield className="h-4 w-4 mr-2" />
                    Your UPJ student card barcode is securely registered for
                    locker access
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Booking Summary */}
          <div>
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle>Booking Summary</CardTitle>
                <CardDescription>Review your reservation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Location
                    </span>
                    <span className="text-sm font-medium">
                      Building B - Library, 4th Floor
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Size</span>
                    <span className="text-sm font-medium">Medium</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Duration
                    </span>
                    <span className="text-sm font-medium">1 Day</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">
                      Start Time
                    </span>
                    <span className="text-sm font-medium">
                      Dec 10, 2024 at 9:00 AM
                    </span>
                  </div>
                </div>

                <div className="border-t pt-3 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Base Rate</span>
                    <span className="text-sm text-success">FREE</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Insurance</span>
                    <span className="text-sm text-success">FREE</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">SMS Notifications</span>
                    <span className="text-sm text-success">FREE</span>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>All Features</span>
                    <span className="text-success">FREE</span>
                  </div>
                </div>

                <div className="border-t pt-3 bg-success/10 rounded-lg p-3">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">Total Cost</span>
                    <span className="text-3xl font-bold text-success">
                      FREE
                    </span>
                  </div>
                  <p className="text-xs text-center text-success mt-2">
                    No charges. No fees. Forever.
                  </p>
                </div>

                <Button
                  className="w-full bg-success hover:bg-success/90"
                  size="lg"
                >
                  Reserve My FREE Locker
                  <Check className="ml-2 h-5 w-5" />
                </Button>

                <div className="text-xs text-muted-foreground text-center">
                  By booking, you agree to our Terms of Service and Privacy
                  Policy. No payment information required.
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Barcode Scanner Modal */}
      <BarcodeScanner
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onSuccess={handleScanSuccess}
        title="Scan UPJ Student Card"
        description="Position your student card barcode in front of the camera"
      />
    </div>
  );
}
