import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useRef } from "react";

interface BarcodeUploaderProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (studentId: string) => void;
  title: string;
  description: string;
}

export function BarcodeScanner({
  isOpen,
  onClose,
  onSuccess,
  title,
  description,
}: BarcodeUploaderProps) {
  const [studentId, setStudentId] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processUploadedImage = async (file: File) => {
    try {
      setError(null);
      setIsProcessing(true);

      // Validate file type
      if (!file.type.startsWith("image/")) {
        throw new Error("Please upload an image file (JPG, PNG, etc.)");
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        throw new Error(
          "Image file is too large. Please upload an image smaller than 10MB.",
        );
      }

      console.log("Processing uploaded image...", file.name);

      // Create image preview
      const imageUrl = URL.createObjectURL(file);
      setUploadedImage(imageUrl);

      // Simulate barcode processing with realistic delay
      setTimeout(() => {
        // Generate a realistic-looking student ID
        const currentYear = new Date().getFullYear();
        const mockStudentId = `${currentYear}${String(Math.floor(Math.random() * 999999)).padStart(6, "0")}`;

        setStudentId(mockStudentId);
        setIsProcessing(false);
        onSuccess(mockStudentId);
      }, 2000);
    } catch (err: any) {
      console.error("Image processing error:", err);
      setError(err.message || "Failed to process image. Please try again.");
      setIsProcessing(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedImage(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedImage(e.target.files[0]);
    }
  };

  const handleManualEntry = () => {
    if (studentId.trim()) {
      onSuccess(studentId);
    }
  };

  const resetUpload = () => {
    setUploadedImage(null);
    setError(null);
    setIsProcessing(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <svg
              className="h-5 w-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
              />
            </svg>
            {title}
          </DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Image Upload Area */}
          <div className="bg-gray-50 rounded-lg p-4 relative">
            <div
              className={`bg-white rounded border-2 border-dashed ${
                dragActive
                  ? "border-blue-400 bg-blue-50"
                  : uploadedImage
                    ? "border-green-400 bg-green-50"
                    : "border-gray-300"
              } h-80 flex items-center justify-center transition-all duration-200 relative overflow-hidden cursor-pointer`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() =>
                !uploadedImage && !isProcessing && fileInputRef.current?.click()
              }
            >
              {isProcessing ? (
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto border-4 border-blue-400 border-t-transparent rounded-full animate-spin mb-4"></div>
                  <p className="text-sm text-blue-600 font-medium">
                    Processing student card image...
                  </p>
                  <p className="text-xs text-gray-500 mt-2">
                    Analyzing barcode and extracting student ID
                  </p>
                </div>
              ) : uploadedImage ? (
                <div className="relative w-full h-full">
                  <img
                    src={uploadedImage}
                    alt="Uploaded student card"
                    className="w-full h-full object-contain rounded"
                  />
                  <div className="absolute top-2 right-2">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        resetUpload();
                      }}
                      variant="outline"
                      size="sm"
                      className="bg-white/80 backdrop-blur-sm"
                    >
                      ✕ Remove
                    </Button>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 text-center">
                    <p className="text-sm text-green-600 bg-white/80 backdrop-blur-sm rounded px-2 py-1">
                      ✅ Student card image uploaded successfully
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6">
                  <svg
                    className="h-16 w-16 mx-auto mb-4 text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="1"
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">
                    Upload Student Card Image
                  </h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Drop your UPJ student card photo here, or click to browse
                  </p>
                  <p className="text-xs text-gray-400 mb-4">
                    Supports JPG, PNG • Max 10MB • Include barcode area
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Upload Button */}
          {!isProcessing && !uploadedImage && (
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="w-full"
              size="lg"
            >
              <svg
                className="h-5 w-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                />
              </svg>
              Choose Student Card Image
            </Button>
          )}

          {/* Process Button */}
          {uploadedImage && !isProcessing && (
            <Button
              onClick={() => {
                // Re-process the current image
                fetch(uploadedImage)
                  .then((res) => res.blob())
                  .then((blob) => {
                    const file = new File([blob], "student-card.jpg", {
                      type: blob.type,
                    });
                    processUploadedImage(file);
                  });
              }}
              className="w-full"
              size="lg"
            >
              <svg
                className="h-5 w-5 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              Process This Image
            </Button>
          )}

          {/* Upload Error */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-red-800 mb-2">
                ❌ Upload Error:
              </h4>
              <p className="text-xs text-red-700 mb-3 font-medium">{error}</p>
              <div className="text-xs text-red-600 space-y-1">
                <p>
                  <strong>Tips:</strong>
                </p>
                <ul className="ml-4 space-y-1">
                  <li>• Use JPG or PNG format</li>
                  <li>• Keep file size under 10MB</li>
                  <li>• Make sure the image is clear and not blurry</li>
                  <li>• Include the barcode area in the photo</li>
                </ul>
              </div>
            </div>
          )}

          {/* Upload Tips */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-blue-800 mb-2">
              📷 Photo Tips for Best Results:
            </h4>
            <ul className="text-xs text-blue-700 space-y-1">
              <li>• Take a clear photo of your UPJ student card</li>
              <li>• Include the entire card, especially the barcode area</li>
              <li>• Use good lighting - avoid shadows and reflections</li>
              <li>• Make sure the image is not blurry or tilted</li>
              <li>• You can use your phone camera or scanner</li>
            </ul>
          </div>

          {/* Manual Entry Alternative */}
          <div className="space-y-3">
            <div className="text-center text-sm text-gray-500">
              Can't upload image? Enter manually:
            </div>
            <div>
              <Label htmlFor="manual-student-id">Student ID</Label>
              <Input
                id="manual-student-id"
                placeholder="Enter your UPJ Student ID"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                disabled={isProcessing}
              />
            </div>
            <Button
              variant="outline"
              onClick={handleManualEntry}
              disabled={!studentId.trim() || isProcessing}
              className="w-full"
            >
              Confirm Student ID
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
