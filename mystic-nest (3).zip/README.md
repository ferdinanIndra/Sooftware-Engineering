# LockerUPJ - Laravel Smart Locker System for UPJ Students

A simple and free locker booking system made specifically for Pembangunan Jaya University (UPJ) students. Built with Laravel for easy setup and management.

## ✨ What is LockerUPJ?

LockerUPJ helps UPJ students:

- 📱 Book lockers using their phone
- 🔒 Store things safely on campus
- 🆓 Use it completely FREE
- 🏫 Find lockers in any UPJ building

## 🚀 Super Easy Setup in VS Code

### Step 1: Get Ready (One Time Only)

1. **Install PHP** from [php.net](https://www.php.net/downloads)

   - Download PHP 8.1 or newer
   - Windows: Use XAMPP from [apachefriends.org](https://www.apachefriends.org/)

2. **Install Composer** from [getcomposer.org](https://getcomposer.org/download/)

   - This helps manage PHP packages

3. **Install VS Code** from [code.visualstudio.com](https://code.visualstudio.com)

### Step 2: Open Project in VS Code

1. Open VS Code
2. Click `File` → `Open Folder`
3. Choose this LockerUPJ folder

### Step 3: Install Laravel (Super Simple!)

1. Open **Terminal** in VS Code (`View` → `Terminal`)
2. Type this and press Enter:

```bash
composer install
```

3. Copy the environment file:

```bash
copy .env.example .env
```

4. Generate application key:

```bash
php artisan key:generate
```

### Step 4: Start the Website

1. In the terminal, type:

```bash
php artisan serve
```

2. You'll see: "Laravel development server started: http://127.0.0.1:8000"
3. Click the link or open your browser and go to `http://127.0.0.1:8000`

**That's it! 🎉 Your LockerUPJ website is running!**

## 📁 Laravel Project Structure (Simple to Understand)

```
app/
├── Http/Controllers/        # All the page logic
│   ├── AuthController.php   # Login/logout
│   ├── DashboardController.php # Student dashboard
│   ├── BookingController.php   # Book lockers
│   └── LockerMapController.php # Campus map

resources/views/             # All the website pages
├── layouts/app.blade.php    # Main layout (header, footer)
├── home.blade.php          # Homepage
├── auth/login.blade.php    # Login page
├── dashboard.blade.php     # Student dashboard
├── booking.blade.php       # Book a locker
└── map.blade.php          # Campus locker map

routes/web.php              # All website addresses
.env                       # Settings (database, etc.)
```

## 🎯 Available Pages

- **Homepage** (`http://127.0.0.1:8000/`) - Introduction and features
- **Login** (`/login`) - Student login with UPJ email
- **Dashboard** (`/dashboard`) - See your active lockers
- **Book Locker** (`/booking`) - Reserve a new locker (FREE!)
- **Campus Map** (`/map`) - Find lockers around UPJ

## 👨‍💻 For Testing/Demo

**Demo Login Credentials:**

- Email: `any-name@student.upj.ac.id` (must end with @student.upj.ac.id)
- Password: `anything` (any password works for demo)

## 🛠️ Common Problems & Solutions

### Problem: "composer: command not found"

**Solution:** Install Composer first, then restart terminal

### Problem: "php: command not found"

**Solution:** Install PHP first (try XAMPP for Windows)

### Problem: "This site can't be reached"

**Solution:** Make sure `php artisan serve` is running in terminal

### Problem: Page shows error

**Solution:**

1. Check if `.env` file exists (copy from `.env.example`)
2. Run `php artisan key:generate`
3. Restart with `php artisan serve`

## 🎨 Want to Change Something?

- **Colors & Styling**: Edit files in `resources/views/`
- **Page Content**: Edit `.blade.php` files in `resources/views/`
- **Website Logic**: Edit controllers in `app/Http/Controllers/`
- **Routes/URLs**: Edit `routes/web.php`
- **University Info**: Search for "UPJ" and replace with your info

## 📊 Why Laravel is Easier

✅ **No Node.js needed** - Just PHP  
✅ **Simple file structure** - Everything organized clearly  
✅ **Built-in features** - Login, database, forms all included  
✅ **Easy deployment** - Works on any web server  
✅ **Great documentation** - Laravel has amazing docs

## 🏫 Made for UPJ Students

This system is designed specifically for Pembangunan Jaya University:

- UPJ building names (Library, Sports Center, etc.)
- UPJ email format (@student.upj.ac.id)
- UPJ-specific features and messaging
- Free for all UPJ students

## 📚 Want to Learn More?

- [Laravel Documentation](https://laravel.com/docs) - Official Laravel docs
- [Blade Templates](https://laravel.com/docs/blade) - How to edit pages
- [Laravel Routing](https://laravel.com/docs/routing) - How URLs work

## 💡 Next Steps (Optional)

- Add real database (SQLite included)
- Add email notifications
- Add real payment system (if needed)
- Deploy to web hosting

---

**Happy coding! 🚀 Your LockerUPJ system is ready for UPJ students!**
